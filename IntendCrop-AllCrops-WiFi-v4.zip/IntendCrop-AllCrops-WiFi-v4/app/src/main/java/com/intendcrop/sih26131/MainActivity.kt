package com.intendcrop.sih26131

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.platform.LocalContext
import android.net.Uri
import android.util.Base64
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import com.intendcrop.sih26131.data.CropRepository
import com.intendcrop.sih26131.model.*
import kotlinx.coroutines.launch

class MainActivity: ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b);setContent{IntendCropApp()}} }

class CropVM: ViewModel(){
    private val repo=CropRepository()
    var detection by mutableStateOf<DetectionResult?>(null); private set
    var risk by mutableStateOf<RiskResult?>(null); private set
    var soil by mutableStateOf<SoilResult?>(null); private set
    var markets by mutableStateOf<List<Market>>(emptyList()); private set
    var cases by mutableStateOf<List<CaseItem>>(emptyList()); private set
    var chat by mutableStateOf<List<Pair<String,Boolean>>>(listOf("Hi! I’m IntendCrop AI. Ask me about crop disease, weather risk, soil or markets." to false)); private set
    var busy by mutableStateOf(false)
    fun detect(c:String, imageBase64:String?=null){ if(imageBase64.isNullOrBlank()) return; busy=true; viewModelScope.launch{ runCatching{repo.detect(c,imageBase64)}.onSuccess{detection=it}.onFailure{detection=DetectionResult(c,"Unable to reach the local AI service",0.0,"Unknown",listOf(it.message ?: "Network error"),listOf("Start the FastAPI backend on port 8000 and try again."),"Local API error") }; busy=false }}
    fun loadRisk(c:String,l:String){busy=true;viewModelScope.launch{runCatching{repo.risk(c,l)}.onSuccess{risk=it}.onFailure{risk=RiskResult(0,"UNKNOWN",c,listOf(it.message ?: "Network error"),listOf("Start the FastAPI backend on port 8000 and try again."))};busy=false}}
    fun loadMarkets(c:String){busy=true;viewModelScope.launch{runCatching{repo.markets(c)}.onSuccess{markets=it}.onFailure{markets=emptyList()};busy=false}}
    fun analyzeSoil(v:SoilResult){busy=true;viewModelScope.launch{runCatching{repo.soil(v)}.onSuccess{soil=it}.onFailure{soil=v.copy(recommendation="Unable to reach the local AI service: ${it.message ?: "network error"}" )};busy=false}}
    fun loadCases(){viewModelScope.launch{runCatching{repo.cases()}.onSuccess{cases=it}}}
    fun updateCase(id:String,status:String){viewModelScope.launch{runCatching{repo.updateCase(id,status)}.onSuccess{loadCases()}}}
    fun sendChat(m:String,c:String,l:String){if(m.isBlank())return;chat=chat+(m to true);viewModelScope.launch{val r=repo.chat(m,c,l);chat=chat+(r.reply to false)}}
    fun createCase(c:String,l:String,s:String){val d=detection ?: return;viewModelScope.launch{repo.createCase(CaseRequest(c,l,s,d.diagnosis,d.confidence,risk?.level?:"UNKNOWN"))}}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun IntendCropApp(vm:CropVM=viewModel()){
    var tab by remember{mutableIntStateOf(0)}
    MaterialTheme(colorScheme=lightColorScheme(primary=Color(0xFF287D45),secondary=Color(0xFF6C9A62),surface=Color(0xFFF7FAF5))){
        Scaffold(topBar={TopAppBar(title={Text("IntendCrop",fontWeight=FontWeight.Bold)},actions={IconButton(onClick={tab=6}){Icon(Icons.Default.AdminPanelSettings,null)}})},bottomBar={NavigationBar{val items=listOf("Home","Detect","Risk","Soil","Markets","Chat");val icons=listOf(Icons.Default.Home,Icons.Default.CameraAlt,Icons.Default.Warning,Icons.Default.Terrain,Icons.Default.Store,Icons.Default.Chat)
            items.forEachIndexed{i,t->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(icons[i],null)},label={Text(t)})}}}){p->Box(Modifier.padding(p).fillMaxSize()){when(tab){0->HomeScreen(vm){tab=1};1->DetectScreen(vm);2->RiskScreen(vm);3->SoilScreen(vm);4->MarketScreen(vm);5->ChatScreen(vm);6->OfficerScreen(vm)}}}}
}

@Composable fun CardBox(modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit){Card(modifier,shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(1.dp)){Column(Modifier.padding(18.dp),content=content)}}
@Composable fun SectionTitle(t:String){Text(t,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(vertical=8.dp))}

@Composable fun HomeScreen(vm:CropVM,onDetect:()->Unit){LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    item{Text("Good morning, Farmer 🌱",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Your field intelligence cockpit",color=Color.Gray)}
    item{CardBox{Text("Field status",fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));Text("🌦  Rain risk: Moderate  •  🌿 Crop: Rice  •  📍 AP") ;Spacer(Modifier.height(12.dp));Button(onClick=onDetect,modifier=Modifier.fillMaxWidth()){Text("Scan a crop now")}}}
    item{SectionTitle("Today’s intelligence")}
    item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Mini("⚠️","Risk","72 / High");Mini("🧪","Soil","Enter values");Mini("💹","Market","₹2,850/q")}}
    item{SectionTitle("How IntendCrop works")}
    item{CardBox{Text("Detect → Predict → Recommend → Act → Verify → Learn",fontWeight=FontWeight.SemiBold);Spacer(Modifier.height(8.dp));Text("Every AI result is paired with confidence, context and an escalation path to an agriculture officer.",color=Color.Gray)}}
    item{SectionTitle("Trusted knowledge")}
    item{CardBox{Text("Recommendations are designed to cite government/agricultural research sources. Product claims should be verified against authorized labels and local advisories.")}}
}}
@Composable fun RowScope.Mini(icon:String,title:String,value:String){CardBox(Modifier.weight(1f)){Text(icon);Text(title,fontWeight=FontWeight.Bold);Text(value,style=MaterialTheme.typography.bodySmall,color=Color.Gray)}}

@Composable fun DetectScreen(vm:CropVM){val context=LocalContext.current;var crop by remember{mutableStateOf("Rice")};var selected by remember{mutableStateOf<Uri?>(null)};val picker=rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()){selected=it}
LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("AI Crop Doctor",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Upload a clear leaf/crop image. Low-confidence results should be escalated.",color=Color.Gray)}
item{CardBox{Text("Crop",fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));OutlinedTextField(crop,{crop=it},modifier=Modifier.fillMaxWidth(),singleLine=true);Spacer(Modifier.height(12.dp));Button(onClick={picker.launch("image/*")},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.UploadFile,null);Spacer(Modifier.width(8.dp));Text(if(selected==null)"Choose image" else "Image selected")};selected?.let{uri->Spacer(Modifier.height(10.dp));AsyncImage(model=uri,contentDescription="Selected crop",modifier=Modifier.fillMaxWidth().height(190.dp),contentScale=ContentScale.Crop)};Spacer(Modifier.height(8.dp));Button(onClick={val b=selected?.let{u->runCatching{context.contentResolver.openInputStream(u)?.use{Base64.encodeToString(it.readBytes(),Base64.NO_WRAP)}}.getOrNull()};vm.detect(crop,b)},enabled=!vm.busy && selected!=null,modifier=Modifier.fillMaxWidth()){Text(if(vm.busy)"Analyzing…" else "Run AI diagnosis")}}}
vm.detection?.let{d->item{CardBox{Text(d.diagnosis,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Text("Confidence ${d.confidence}% • ${d.severity}");Spacer(Modifier.height(10.dp));Text("Symptoms",fontWeight=FontWeight.Bold);d.symptoms.forEach{Text("• $it")};Spacer(Modifier.height(8.dp));Text("Recommended next steps",fontWeight=FontWeight.Bold);d.actions.forEach{Text("✓ $it")};Spacer(Modifier.height(10.dp));OutlinedButton(onClick={},modifier=Modifier.fillMaxWidth()){Text("Request officer verification")}}}}
}}

@Composable fun RiskScreen(vm:CropVM){var crop by remember{mutableStateOf("Rice")};var loc by remember{mutableStateOf("Vizianagaram, Andhra Pradesh")};LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("Early Risk Radar",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)};item{CardBox{OutlinedTextField(crop,{crop=it},label={Text("Crop")},modifier=Modifier.fillMaxWidth());OutlinedTextField(loc,{loc=it},label={Text("Location")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(10.dp));Button(onClick={vm.loadRisk(crop,loc)},modifier=Modifier.fillMaxWidth()){Text("Predict 7-day risk")}}};vm.risk?.let{r->item{CardBox{Text("${r.score}/100  ${r.level}",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("Risk drivers",fontWeight=FontWeight.Bold);r.drivers.forEach{Text("• $it")};Spacer(Modifier.height(8.dp));Text("Actions",fontWeight=FontWeight.Bold);r.actions.forEach{Text("✓ $it")}}}}}}

@Composable fun SoilScreen(vm:CropVM){var crop by remember{mutableStateOf("Rice")};var ph by remember{mutableStateOf("6.5")};var n by remember{mutableStateOf("120")};var p by remember{mutableStateOf("35")};var k by remember{mutableStateOf("180")};var ec by remember{mutableStateOf("0.8")};LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Soil Intelligence",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Use laboratory values when available. Image-only soil estimates are not lab replacements.",color=Color.Gray)};item{CardBox{listOf("Crop" to crop,"pH" to ph,"Nitrogen (kg/ha)" to n,"Phosphorus (kg/ha)" to p,"Potassium (kg/ha)" to k,"EC (dS/m)" to ec).forEachIndexed{idx,(label,v)->OutlinedTextField(v,{x->when(idx){0->crop=x;1->ph=x;2->n=x;3->p=x;4->k=x;5->ec=x}},label={Text(label)},modifier=Modifier.fillMaxWidth(),singleLine=true);Spacer(Modifier.height(5.dp))};Button(onClick={vm.analyzeSoil(SoilResult(ph.toDoubleOrNull()?:6.5,n.toDoubleOrNull()?:120.0,p.toDoubleOrNull()?:35.0,k.toDoubleOrNull()?:180.0,ec.toDoubleOrNull()?:0.8,crop,""))},modifier=Modifier.fillMaxWidth()){Text("Analyze soil")}}};vm.soil?.let{s->item{CardBox{Text("Recommendation",fontWeight=FontWeight.Bold);Text(s.recommendation)}}}}}

@Composable fun MarketScreen(vm:CropVM){var crop by remember{mutableStateOf("Rice")};LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Market Intelligence",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);OutlinedTextField(crop,{crop=it},label={Text("Crop")},modifier=Modifier.fillMaxWidth());Button(onClick={vm.loadMarkets(crop)},modifier=Modifier.fillMaxWidth()){Text("Compare nearby markets")}};items(vm.markets){m->CardBox{Text(m.market,fontWeight=FontWeight.Bold);Text("${m.crop} • ₹${m.price}/q");Text("${m.distanceKm} km • transport ₹${m.transport.toInt()} • estimated net ₹${m.net.toInt()}",color=Color.Gray)}}}}

@Composable fun ChatScreen(vm:CropVM){var msg by remember{mutableStateOf("")};LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{Text("Krishi AI Assistant",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Ask in simple language; connect the answer to crop + location context.",color=Color.Gray)};items(vm.chat){(m,user)->Row(Modifier.fillMaxWidth(),horizontalArrangement=if(user)Arrangement.End else Arrangement.Start){CardBox(Modifier.widthIn(max=320.dp)){Text(m)}}};item{Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(msg,{msg=it},modifier=Modifier.weight(1f),placeholder={Text("Ask about disease, soil, weather…")});IconButton(onClick={val x=msg;msg="";vm.sendChat(x,"Rice","Andhra Pradesh")}){Icon(Icons.Default.Send,null)}}}}}

@Composable fun OfficerScreen(vm:CropVM){LaunchedEffect(Unit){vm.loadCases()};LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Officer Command Center",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Triage cases, hotspots and intervention status",color=Color.Gray)};item{CardBox{Text("Priority queue",fontWeight=FontWeight.Bold);Text("HIGH risk cases should be reviewed first. Validate AI diagnosis before treatment recommendations.")}};items(vm.cases){c->CardBox{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(c.id,fontWeight=FontWeight.Bold);Text(c.risk,fontWeight=FontWeight.Bold)};Text("${c.crop} • ${c.location}");Text(c.diagnosis);Text(c.status,color=Color.Gray);Spacer(Modifier.height(8.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={vm.updateCase(c.id,"Validated")}){Text("Validate")};OutlinedButton(onClick={vm.updateCase(c.id,"Needs more information")}){Text("Request info")}}}};item{CardBox{Text("Hotspot map",fontWeight=FontWeight.Bold);Text("Prototype view: Vizianagaram • Srikakulam • Guntur. Connect this card to a GIS layer (GeoJSON/Map SDK) for live case clustering and predicted risk zones.")}}}}
