package com.intendcrop.sih26131.data
object ServerConfig {
    // Change to your Windows PC Wi-Fi IPv4, e.g. http://192.168.1.105:8000/
    const val BASE_URL = "http://192.168.1.100:8000/"
}
