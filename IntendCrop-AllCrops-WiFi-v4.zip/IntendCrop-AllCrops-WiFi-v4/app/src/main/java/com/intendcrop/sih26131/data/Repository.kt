package com.intendcrop.sih26131.data

import com.intendcrop.sih26131.model.*
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class CropRepository {
    private val api: CropApi

    init {
        val log = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC }
        val client = OkHttpClient.Builder()
            .addInterceptor(log)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
        api = Retrofit.Builder()
            .baseUrl(ServerConfig.BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(CropApi::class.java)
    }

    suspend fun detect(crop: String, imageBase64: String): DetectionResult = api.detect(DetectRequest(crop, imageBase64))
    suspend fun risk(crop: String, location: String) = api.risk(crop, location)
    suspend fun soil(v: SoilResult) = api.soil(v)
    suspend fun markets(crop: String) = api.markets(crop)
    suspend fun chat(message: String, crop: String, location: String) = api.chat(ChatRequest(message, crop, location))
    suspend fun createCase(r: CaseRequest) = api.createCase(r)
    suspend fun cases() = api.cases()
    suspend fun updateCase(id: String, status: String, notes: String = "") = api.updateCase(id, CaseUpdate(status, notes))
}
