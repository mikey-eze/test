package com.intendcrop.sih26131.model

data class DetectionResult(val crop: String, val diagnosis: String, val confidence: Double, val severity: String, val symptoms: List<String>, val actions: List<String>, val source: String = "IntendCrop AI", val detectionId: Int? = null)
data class RiskResult(val score: Int, val level: String, val crop: String, val drivers: List<String>, val actions: List<String>)
data class SoilResult(val pH: Double, val nitrogen: Double, val phosphorus: Double, val potassium: Double, val ec: Double, val crop: String, val recommendation: String, val estimated: Boolean = false)
data class Market(val market: String, val crop: String, val price: Double, val distanceKm: Double, val transport: Double, val net: Double)
data class CaseItem(val id: String, val location: String, val crop: String, val diagnosis: String, val risk: String, val status: String)
data class ChatReply(val reply: String, val sources: List<String>)
data class DetectRequest(val crop: String, val imageBase64: String? = null)
data class ChatRequest(val message: String, val crop: String, val location: String)
data class CaseRequest(val crop: String, val location: String, val stage: String, val diagnosis: String, val confidence: Double, val risk: String)
