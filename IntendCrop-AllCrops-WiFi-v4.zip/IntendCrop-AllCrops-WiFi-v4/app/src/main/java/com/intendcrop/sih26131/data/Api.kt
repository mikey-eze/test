package com.intendcrop.sih26131.data

import com.intendcrop.sih26131.model.*
import retrofit2.http.Body
import retrofit2.http.PATCH
import retrofit2.http.Path
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

data class CaseUpdate(val status: String, val notes: String = "")

interface CropApi {
    @POST("detect") suspend fun detect(@Body request: DetectRequest): DetectionResult
    @GET("risk") suspend fun risk(@Query("crop") crop: String, @Query("location") location: String): RiskResult
    @POST("soil") suspend fun soil(@Body soil: SoilResult): SoilResult
    @GET("markets") suspend fun markets(@Query("crop") crop: String): List<Market>
    @POST("chat") suspend fun chat(@Body request: ChatRequest): ChatReply
    @POST("cases") suspend fun createCase(@Body request: CaseRequest): CaseItem
    @GET("cases") suspend fun cases(): List<CaseItem>
    @PATCH("cases/{id}") suspend fun updateCase(@Path("id") id: String, @Body request: CaseUpdate): CaseItem
}
