OPTIONAL PRODUCTION MODEL
Place a trained crop-disease model here when integrating on-device inference.
Recommended deployment formats: TensorFlow Lite or ONNX. Keep the output labels aligned with the backend /detect contract.
The supplied project intentionally does not ship an unverified model; the backend baseline keeps the prototype runnable end-to-end.
