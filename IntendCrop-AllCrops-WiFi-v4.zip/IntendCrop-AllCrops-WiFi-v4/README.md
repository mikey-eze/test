# IntendCrop All-Crop AI + Wi-Fi

FastAPI uses Kindwise crop.health as the food-crop primary engine and plant.id + plant.health as a broad fallback. crop.health currently covers 23 major crops and about 288 health issues; plant.id covers 35,000+ plant classes and plant.health covers 548 health conditions.

## Setup
1. `cd backend`
2. Copy `.env.example` to `.env` and add keys.
3. `pip install -r requirements.txt`
4. `python -m uvicorn main:app --host 0.0.0.0 --port 8000`
5. `ipconfig` -> get Windows Wi-Fi IPv4.
6. Allow TCP 8000 in Windows Firewall if needed.
7. Change `ServerConfig.kt` to that PC IP.
8. Put test phones on the same Wi-Fi.

Never put Kindwise API keys in Android.
