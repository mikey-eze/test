# IntendCrop API contract

Base URL for Android emulator: `http://10.0.2.2:8000/`

- GET `/health`
- POST `/detect` `{crop,imageBase64}`
- GET `/risk?crop=Rice&location=Andhra%20Pradesh`
- POST `/soil`
- GET `/markets?crop=Rice`
- POST `/chat` `{message,crop,location}`
- POST `/cases`
- GET `/cases`

The Android repository uses a local demo fallback if the backend is offline, so the UI can still be demonstrated.

### `/detect` local AI behavior
The endpoint runs image quality and plant-presence gates, then selects a crop-specific local classifier. Rice/paddy uses the dedicated rice EfficientNet-B0 model; other crops use the 38-class PlantVillage MobileNetV2 model. The first run may download model files from Hugging Face.
