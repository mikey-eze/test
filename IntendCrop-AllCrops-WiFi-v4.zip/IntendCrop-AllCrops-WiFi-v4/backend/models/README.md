# IntendCrop Local AI Models

The backend now uses real image-classification models rather than a fake/demo diagnosis.

## Automatic model download

From `backend/` run:

```bat
pip install -r requirements.txt
python download_models.py
```

The models are downloaded from Hugging Face and cached on the computer. No Gemini API key is required.

### Rice / paddy
`Huyt/rice-leaf-disease-efficientnet-b0`

- EfficientNet-B0
- 17 rice conditions
- ~4.07M parameters
- Model card reports 97.09% held-out accuracy and 94.73% macro-F1
- Intended for research/educational rice disease triage

### Other supported PlantVillage crops
`linkanjarad/mobilenet_v2_1.0_224-plant-disease-identification`

- MobileNetV2
- 38 PlantVillage disease/healthy classes
- Model card reports 95.41% evaluation accuracy

## Important

These are decision-support models, not confirmed agronomist diagnoses. Real-world field conditions can reduce accuracy, so low-confidence results should be verified.
