"""IntendCrop local development backend.

Run: pip install -r requirements.txt && uvicorn main:app --host 0.0.0.0 --port 8000 --reload

Database: SQLite by default (intendcrop.db). Set DATABASE_URL for PostgreSQL later.
Detection: real image validation + optional YOLO/ONNX model adapters. The service NEVER
returns a fabricated disease result when no trained disease model is installed.
"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timezone
from pathlib import Path
import base64, io, os, uuid, json
from dotenv import load_dotenv
from PIL import Image, ImageStat
from crop_ai import predict as predict_crop_ai

from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text
from sqlalchemy.orm import declarative_base, sessionmaker

app = FastAPI(title="IntendCrop Local AI + Data Service", version="3.0.0")
BASE = Path(__file__).resolve().parent
load_dotenv(BASE / ".env")
UPLOADS = BASE / "uploads"
UPLOADS.mkdir(exist_ok=True)
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{BASE / 'intendcrop.db'}")
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
Base = declarative_base()

class Detection(Base):
    __tablename__ = "detections"
    id = Column(Integer, primary_key=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    crop = Column(String, nullable=False)
    diagnosis = Column(String, nullable=False)
    confidence = Column(Float, nullable=False)
    severity = Column(String, nullable=False)
    source = Column(String, nullable=False)
    image_path = Column(String, nullable=True)

class Case(Base):
    __tablename__ = "cases"
    id = Column(String, primary_key=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    crop = Column(String, nullable=False)
    location = Column(String, nullable=False)
    stage = Column(String, nullable=False)
    diagnosis = Column(String, nullable=False)
    confidence = Column(Float, nullable=False)
    risk = Column(String, nullable=False)
    status = Column(String, default="Officer review")
    notes = Column(Text, default="")

class Feedback(Base):
    __tablename__ = "feedback"
    id = Column(Integer, primary_key=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    detection_id = Column(Integer, nullable=True)
    outcome = Column(String, nullable=False)
    notes = Column(Text, default="")

Base.metadata.create_all(engine)

class DetectRequest(BaseModel):
    crop: str = "Unknown"
    imageBase64: Optional[str] = None

class SoilRequest(BaseModel):
    pH: float; nitrogen: float; phosphorus: float; potassium: float; ec: float
    crop: str; recommendation: str = ""; estimated: bool = False

class ChatRequest(BaseModel):
    message: str; crop: str; location: str

class CaseRequest(BaseModel):
    crop: str; location: str; stage: str; diagnosis: str; confidence: float; risk: str

class CaseUpdate(BaseModel):
    status: str
    notes: str = ""

class FeedbackRequest(BaseModel):
    detectionId: Optional[int] = None
    outcome: str
    notes: str = ""

def decode_image(raw: Optional[str]):
    if not raw: raise ValueError("No image supplied")
    if "," in raw: raw = raw.split(",", 1)[1]
    data = base64.b64decode(raw, validate=True)
    image = Image.open(io.BytesIO(data)).convert("RGB")
    if image.width < 160 or image.height < 160:
        raise ValueError("Image is too small")
    return image, data

def image_quality(image: Image.Image):
    # Lightweight, deterministic quality gate. This is not a disease diagnosis.
    stat = ImageStat.Stat(image.resize((64, 64)).convert("L"))
    brightness = stat.mean[0]
    if brightness < 35: return False, "Image is too dark. Take the photo in better light."
    if brightness > 245: return False, "Image is overexposed. Avoid direct glare."
    return True, "OK"

def plant_visual_gate(image: Image.Image):
    # Green-pixel ratio is a simple plant-presence gate, not a trained classifier.
    import numpy as np
    arr = np.asarray(image.resize((160, 160)))
    r,g,b = arr[:,:,0],arr[:,:,1],arr[:,:,2]
    green = ((g > r*1.08) & (g > b*1.05) & (g > 45)).mean()
    return green >= 0.025, float(green)

def optional_model_inference(image: Image.Image, crop: str, raw_bytes: bytes):
    return predict_crop_ai(raw_bytes)

def run_detection(crop, image, image_bytes):
    ok, reason = image_quality(image)
    if not ok:
        return {"crop": crop, "diagnosis": "Image quality insufficient", "confidence": 0.0, "severity": "Unknown", "symptoms": [reason], "actions": ["Retake a clear close-up image of the affected leaf or plant."], "source": "Image quality gate"}
    present, ratio = plant_visual_gate(image)
    if not present:
        return {"crop": crop, "diagnosis": "No clear plant detected", "confidence": round(min(ratio * 100, 100), 1), "severity": "Unknown", "symptoms": ["The image does not contain enough visible plant-like area for this prototype."], "actions": ["Point the camera at the leaf/plant and fill most of the frame."], "source": "Plant presence gate"}
    model_result = optional_model_inference(image, crop, image_bytes)
    if model_result:
        return {"crop": crop, **model_result}
    return {"crop": crop, "diagnosis": "AI model unavailable", "confidence": 0.0, "severity": "Unknown", "symptoms": ["The image passed the plant-presence check but no local model result was available."], "actions": ["Check the AI dependencies and model download."], "source": "IntendCrop local AI"}

@app.get("/health")
def health():
    return {"status":"ok","service":"IntendCrop","database":DATABASE_URL.split(":",1)[0],"time":datetime.now(timezone.utc).isoformat()}

@app.post("/detect")
def detect(req: DetectRequest):
    if not req.imageBase64: raise HTTPException(400, "An image is required for real detection")
    try: image, raw = decode_image(req.imageBase64)
    except Exception as e: raise HTTPException(400, f"Invalid image: {e}")
    result = run_detection(req.crop, image, raw)
    path = UPLOADS / f"{uuid.uuid4().hex}.jpg"
    image.save(path, quality=88)
    db = SessionLocal()
    row = Detection(crop=result.get("crop", req.crop), diagnosis=result["diagnosis"], confidence=result["confidence"], severity=result["severity"], source=result["source"], image_path=str(path))
    db.add(row); db.commit(); db.refresh(row); db.close()
    result["detectionId"] = row.id
    return result

@app.get("/risk")
def risk(crop: str="Rice", location: str="Unknown", humidity: float=65, precipitation: float=0, temperature: float=28):
    score = 30
    drivers=[]
    if humidity >= 80: score += 25; drivers.append("High humidity")
    elif humidity >= 70: score += 12; drivers.append("Moderately high humidity")
    if precipitation >= 20: score += 25; drivers.append("Heavy recent/forecast precipitation")
    elif precipitation >= 5: score += 10; drivers.append("Rainfall present")
    if temperature >= 34: score += 12; drivers.append("High temperature")
    if not drivers: drivers.append("No major weather trigger in supplied data")
    score=max(0,min(100,score))
    level="CRITICAL" if score>=85 else "HIGH" if score>=65 else "MEDIUM" if score>=40 else "LOW"
    actions=["Scout the crop within 24 hours"] if score>=65 else ["Continue routine scouting"]
    if precipitation>=5: actions.append("Check field drainage and avoid unnecessary irrigation")
    return {"score":score,"level":level,"crop":crop,"location":location,"drivers":drivers,"actions":actions}

@app.post("/soil")
def soil(s: SoilRequest):
    rec=[]
    if s.pH < 5.5: rec.append("pH is acidic; verify with a laboratory soil test and follow local guidance.")
    elif s.pH > 8.0: rec.append("pH is alkaline; verify with a laboratory soil test and follow local guidance.")
    else: rec.append("pH is in a generally suitable range for many crops.")
    rec.append("Use crop- and soil-test-specific nutrient recommendations rather than blanket fertilizer dosing.")
    return {**s.model_dump(),"recommendation":" ".join(rec),"estimated":False}

@app.get("/markets")
def markets(crop: str="Rice"):
    # Clearly marked prototype data until a verified market feed is configured.
    return [{"market":"Local APMC (prototype)","crop":crop,"price":2850,"distanceKm":12,"transport":180,"net":2670,"source":"Prototype — replace with verified feed"}, {"market":"District Market (prototype)","crop":crop,"price":3010,"distanceKm":34,"transport":430,"net":2580,"source":"Prototype — replace with verified feed"}, {"market":"Farmer Collective (prototype)","crop":crop,"price":2940,"distanceKm":18,"transport":220,"net":2720,"source":"Prototype — replace with verified feed"}]

@app.post("/chat")
def chat(req: ChatRequest):
    q=req.message.lower()
    if any(x in q for x in ["yellow","spot","disease","leaf","pest"]):
        text=f"For {req.crop} in {req.location}, use the Crop Doctor image result as a clue, not a confirmed diagnosis. If confidence is low or symptoms spread quickly, request expert validation."
    elif any(x in q for x in ["soil","fert"]):
        text="Use your latest soil-test values and crop stage. Prefer soil-test-based recommendations from trusted agricultural sources."
    elif any(x in q for x in ["rain","weather","heat"]):
        text="Weather becomes useful when connected to your crop. Check drainage after rain, avoid unnecessary irrigation, and scout for disease after prolonged leaf wetness."
    else:
        text=f"I can help with {req.crop} in {req.location}. Tell me the crop symptom, growth stage, recent weather, or soil-test values."
    return {"reply":text,"sources":["ICAR / agricultural research sources","State Agriculture Department","Local KVK / agriculture officer"]}

@app.post("/cases")
def create_case(req: CaseRequest):
    db=SessionLocal(); cid=f"IC-{uuid.uuid4().hex[:8].upper()}"
    row=Case(id=cid,crop=req.crop,location=req.location,stage=req.stage,diagnosis=req.diagnosis,confidence=req.confidence,risk=req.risk,status="Officer review")
    db.add(row); db.commit(); db.refresh(row); out={"id":row.id,"location":row.location,"crop":row.crop,"diagnosis":row.diagnosis,"risk":row.risk,"status":row.status}; db.close(); return out

@app.get("/cases")
def cases():
    db=SessionLocal(); rows=db.query(Case).order_by(Case.created_at.desc()).all(); out=[{"id":r.id,"location":r.location,"crop":r.crop,"diagnosis":r.diagnosis,"risk":r.risk,"status":r.status} for r in rows]; db.close(); return out

@app.patch("/cases/{case_id}")
def update_case(case_id: str, req: CaseUpdate):
    allowed={"Officer review","Validated","Needs more information","Rejected","Closed"}
    if req.status not in allowed: raise HTTPException(400,"Invalid case status")
    db=SessionLocal(); row=db.get(Case,case_id)
    if not row: db.close(); raise HTTPException(404,"Case not found")
    row.status=req.status; row.notes=req.notes; db.commit(); out={"id":row.id,"status":row.status,"notes":row.notes}; db.close(); return out

@app.post("/feedback")
def feedback(req: FeedbackRequest):
    db=SessionLocal(); row=Feedback(detection_id=req.detectionId,outcome=req.outcome,notes=req.notes); db.add(row); db.commit(); db.refresh(row); db.close(); return {"id":row.id,"status":"recorded"}
