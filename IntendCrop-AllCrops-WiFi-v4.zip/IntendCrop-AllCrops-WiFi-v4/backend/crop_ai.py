from __future__ import annotations
import base64, os, tempfile
from pathlib import Path
from typing import Any
import requests
CROP_HEALTH_URL="https://crop.kindwise.com/api/v1/identification"

def b64(data:bytes)->str: return base64.b64encode(data).decode("ascii")
def top(items): return max(items or [], key=lambda x: float(x.get("probability",0)), default=None)
def text(details, keys):
 out=[]
 for k in keys:
  v=(details or {}).get(k)
  if isinstance(v,str) and v.strip(): out.append(v.strip())
  elif isinstance(v,list): out += [str(x) for x in v if x]
 return out
def crop_health(data:bytes):
 key=os.getenv("KINDWISE_CROP_HEALTH_API_KEY","").strip()
 if not key: return None
 r=requests.post(CROP_HEALTH_URL,params={"details":"taxonomy,description,symptoms,treatment,severity,spreading,eppo_code,gbif_id","language":"en"},headers={"Api-Key":key,"Content-Type":"application/json"},json={"images":[b64(data)]},timeout=60)
 r.raise_for_status(); res=r.json().get("result",{})
 crop=top((res.get("crop") or {}).get("suggestions")); disease=top((res.get("disease") or {}).get("suggestions"))
 if not crop: return None
 cd=crop.get("details") or {}; dd=(disease or {}).get("details") or {}; common=cd.get("common_names") or []
 cname=common[0] if isinstance(common,list) and common else crop.get("name","Unknown crop")
 cc=float(crop.get("probability",0))*100
 if disease:
  diagnosis=disease.get("name","Unknown health issue"); conf=float(disease.get("probability",0))*100; severity=dd.get("severity") or ("High" if conf>=85 else "Moderate" if conf>=65 else "Low"); symptoms=text(dd,("symptoms","description")); tr=dd.get("treatment") or {}; actions=[]
  if isinstance(tr,dict):
   for k in ("prevention","biological","chemical"):
    if isinstance(tr.get(k),list): actions += [str(x) for x in tr[k][:4]]
  elif isinstance(tr,str): actions=[tr]
  if not actions: actions=["Confirm the result with a local agriculture officer before treatment."]
 else:
  diagnosis="Healthy / no major health issue suggested"; conf=cc; severity="Healthy"; symptoms=["No major health issue was suggested by the crop-health model."]; actions=["Continue routine scouting and monitor the crop."]
 return {"crop":cname,"scientificName":crop.get("name",cname),"cropConfidence":round(cc,1),"diagnosis":diagnosis,"confidence":round(conf,1),"severity":severity,"symptoms":symptoms or ["See the AI assessment for details."],"actions":actions,"source":"Kindwise crop.health API","model":"crop.health"}
def plant_health(path:Path):
 key=os.getenv("KINDWISE_PLANT_API_KEY","").strip()
 if not key: return None
 from kindwise import PlantApi
 api=PlantApi(key); ident=api.identify(str(path),details=["common_names","taxonomy","url"]); res=ident.result
 if getattr(getattr(res,"is_plant",None),"binary",True) is False: return {"crop":"Unknown","scientificName":"","cropConfidence":0,"diagnosis":"No plant confidently detected","confidence":0,"severity":"Unknown","symptoms":["The image was not confidently classified as a plant."],"actions":["Take a clear photo of the crop."],"source":"Kindwise plant.id","model":"plant.id"}
 ss=getattr(getattr(res,"classification",None),"suggestions",[]) or []; p=top([{"probability":getattr(x,"probability",0),"obj":x} for x in ss]); obj=p["obj"] if p else None
 if obj is None: return None
 name=getattr(obj,"name","Unknown plant"); conf=float(getattr(obj,"probability",0))*100; det=getattr(obj,"details",{}) or {}; common=det.get("common_names",[]) if isinstance(det,dict) else []; cname=common[0] if isinstance(common,list) and common else name
 health=api.health_assessment(str(path),details=["description","treatment","common_names"]); hr=health.result; healthy=getattr(getattr(hr,"is_healthy",None),"binary",None); ds=getattr(getattr(hr,"disease",None),"suggestions",[]) or []
 if healthy is True or not ds: return {"crop":cname,"scientificName":name,"cropConfidence":round(conf,1),"diagnosis":"Healthy / no major health issue suggested","confidence":round(conf,1),"severity":"Healthy","symptoms":["No major harmful condition was suggested by the health model."],"actions":["Continue routine scouting and monitoring."],"source":"Kindwise plant.id + plant.health","model":"plant.id/plant.health"}
 d=top([{"probability":getattr(x,"probability",0),"obj":x} for x in ds]); dobj=d["obj"]; dc=float(getattr(dobj,"probability",0))*100; dd=getattr(dobj,"details",{}) or {}; tr=dd.get("treatment") if isinstance(dd,dict) else None; actions=[]
 if isinstance(tr,dict):
  for k in ("prevention","biological","chemical"):
   if isinstance(tr.get(k),list): actions += [str(x) for x in tr[k][:4]]
 elif isinstance(tr,str): actions=[tr]
 return {"crop":cname,"scientificName":name,"cropConfidence":round(conf,1),"diagnosis":getattr(dobj,"name","Unknown health issue"),"confidence":round(dc,1),"severity":"High" if dc>=85 else "Moderate" if dc>=65 else "Low","symptoms":[dd.get("description")] if isinstance(dd,dict) and dd.get("description") else ["Potential health issue detected."],"actions":actions or ["Confirm the result with a qualified agriculture officer before treatment."],"source":"Kindwise plant.id + plant.health","model":"plant.id/plant.health"}
def predict(data:bytes):
 try:
  r=crop_health(data)
  if r: return r
 except Exception as e: crop_error=str(e)
 if not os.getenv("KINDWISE_PLANT_API_KEY","").strip(): return {"crop":"Unknown","scientificName":"","cropConfidence":0,"diagnosis":"AI service not configured","confidence":0,"severity":"Unknown","symptoms":["No Kindwise API key is configured on the FastAPI server."],"actions":["Copy backend/.env.example to backend/.env and add a Kindwise API key."],"source":"IntendCrop configuration","model":"none"}
 with tempfile.NamedTemporaryFile(suffix=".jpg",delete=False) as f: f.write(data); p=Path(f.name)
 try: return plant_health(p) or {"crop":"Unknown","scientificName":"","cropConfidence":0,"diagnosis":"No confident result","confidence":0,"severity":"Unknown","symptoms":["The AI service returned no confident result."],"actions":["Retake a clear close-up image."],"source":"Kindwise","model":"none"}
 except Exception as e: return {"crop":"Unknown","scientificName":"","cropConfidence":0,"diagnosis":"AI request failed","confidence":0,"severity":"Unknown","symptoms":[str(e)],"actions":["Check API key, internet connection, and account credits."],"source":"Kindwise API error","model":"none"}
 finally:
  try:p.unlink()
  except:pass
